# Global Market Correlation Explorer

No API keys anywhere — `yfinance` pulls free public data straight from Yahoo Finance.

## Files
- `correlation_utils.py` — all the analysis logic (download, log returns, correlation, heatmap, Sankey). Both entry points below import from this, so there's one source of truth. Heatmap/Sankey builders accept an optional `theme` dict — pass nothing and you get the original light look; the app passes the dark palette.
- `market_hours.py` — approximate real open/closed status per exchange (timezone + regular session hours), used for the "market pulse" strip at the top of the app.
- `theme.py` — the app's visual identity: colors, fonts, and the injected CSS block.
- `market_correlation_script.py` — the original plain-Python script, fixed, using all 15 default indices. Run with `python market_correlation_script.py`. Saves `global_market_correlation.png` and `correlation_sankey.html`.
- `app.py` — the Streamlit app.
- `.streamlit/config.toml` — Streamlit's native dark theme (sidebar, buttons, sliders, etc.). **Keep this in a folder literally named `.streamlit` next to `app.py`** — Streamlit only picks it up from that exact location.

## Run it

```bash
pip install -r requirements.txt

# CLI script (all 15 default indices, unstyled — matches your original output)
python market_correlation_script.py

# Streamlit app (pick your own markets, full UI)
streamlit run app.py
```

The app opens at `http://localhost:8501`.

## What the redesign changed

- **Palette** — "trading floor at dawn": deep ink background (`#0E1420`), signal teal for positive correlation / open markets, ember rose for negative / closed, amber for headline numbers. Applied consistently across Streamlit's own widgets (via `.streamlit/config.toml`), the matplotlib heatmap (custom colormap, not default `coolwarm`), and the Plotly Sankey — one visual system instead of three unstyled libraries side by side.
- **Type** — Space Grotesk for headings, Inter for body text, IBM Plex Mono for every number and ticker, loaded as web fonts via the injected CSS. (Matplotlib can't load web fonts the way a browser can, so the heatmap figure itself keeps its default font — only its colors are themed; see the comment in `build_heatmap_figure`.)
- **Market pulse strip** — a signature element above the results: a chip per selected market showing its exchange, local time, and live open/closed status, computed from real timezones and regular trading hours (approximate — it doesn't know about public holidays, noted in-app).
- **Sankey now shows your selection, not a fixed top-20** — since you're hand-picking markets, the diagram shows every pair between them by default, with a slider to narrow to the strongest N once you pick more than ~12 markets (otherwise the diagram gets cluttered).
- **Layout** — hero header, card-styled metrics, tabbed results (Heatmap / Sankey / Pairs table / Raw data), download buttons for the heatmap PNG, Sankey HTML, and close-price CSV.

## Two real bugs fixed along the way

1. **Pairwise correlation table was silently duplicated.** The original `corr.where(mask).stack().reset_index()` relied on `.stack()` auto-dropping NaN rows — a default pandas removed in 2.1+ (so also in pandas 3.0, what a plain `pip install pandas` gives you today). Without it, 5 tickers gave 25 "pairs" instead of 10 (every pair doubled, plus the empty diagonal), silently corrupting the heatmap and Sankey. Fixed with an explicit `.dropna()` after `.stack()`.
2. **A ticker that came back with data but all `NaN` wasn't flagged as missing.** The "missing tickers" check ran before the all-`NaN` columns got dropped, so a real Yahoo Finance hiccup (ticker present in the response, no actual prices) went unreported — the app would just quietly shrink to fewer markets with no warning. Fixed by computing the missing-ticker list after the cleanup step.

## Note on testing

I don't have network access to Yahoo Finance from this sandbox (only a small allowlist of dev-tool domains), so I validated everything against synthetic multi-ticker price data shaped exactly like yfinance's real output — including running the **actual app.py** through Streamlit's `AppTest` harness (clicking "Run analysis", checking the metrics/tables/Sankey render, and forcing an error path with a ticker that returns no data) rather than just confirming the page loads. The real `yf.download(...)` call is untouched standard yfinance usage, so it'll hit the real API fine on your machine.
